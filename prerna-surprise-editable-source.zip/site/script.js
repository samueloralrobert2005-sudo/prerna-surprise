// ============================================================
// FOR PRERNA — interactions & content data
// ============================================================

/* ---------- reusable kitten SVG (simple, cute line-art) ---------- */
const KITTEN_SVG = `
<svg viewBox="0 0 100 90" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#e6bf76" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
  <path d="M20 34 L28 14 L38 30 Z"/>
  <path d="M80 34 L72 14 L62 30 Z"/>
  <ellipse cx="50" cy="52" rx="34" ry="28" fill="#2a2048"/>
  <path d="M20 34 L28 14 L38 30 Z" fill="#2a2048"/>
  <path d="M80 34 L72 14 L62 30 Z" fill="#2a2048"/>
  <circle cx="38" cy="50" r="3.2" fill="#e6bf76" stroke="none"/>
  <circle cx="62" cy="50" r="3.2" fill="#e6bf76" stroke="none"/>
  <path d="M46 58 Q50 62 54 58" />
  <path d="M50 58 L50 54" />
  <path d="M14 60 Q6 58 4 52" />
  <path d="M14 66 Q6 68 4 72" />
  <path d="M86 60 Q94 58 96 52" />
  <path d="M86 66 Q94 68 96 72" />
</svg>`;

function kittenWithProp(prop){
  // prop: 'heart' | 'flower' | 'zzz' | 'sign' | 'confetti' | ''
  let extra = '';
  if(prop === 'heart'){
    extra = `<path d="M50 76 c-6 -6 -14 -4 -14 3 c0 6 14 14 14 14 s14 -8 14 -14 c0 -7 -8 -9 -14 -3 Z" fill="#e29a9a" stroke="none"/>`;
  } else if(prop === 'flower'){
    extra = `<g transform="translate(50,80)"><circle r="3" fill="#f0d9a3" stroke="none"/>
      <circle cx="-5" cy="-2" r="3.2" fill="#e29a9a" stroke="none"/>
      <circle cx="5" cy="-2" r="3.2" fill="#e29a9a" stroke="none"/>
      <circle cx="0" cy="4" r="3.2" fill="#e29a9a" stroke="none"/>
      <circle cx="0" cy="-6" r="3.2" fill="#e29a9a" stroke="none"/></g>`;
  } else if(prop === 'zzz'){
    extra = `<text x="66" y="20" font-size="14" fill="#e6bf76" stroke="none" font-family="Georgia,serif">z z Z</text>`;
  } else if(prop === 'sign'){
    extra = `<rect x="38" y="76" width="24" height="12" rx="2" fill="#faf2e6" stroke="#e6bf76" stroke-width="1.5"/>
      <text x="50" y="85" font-size="7" fill="#2b2138" stroke="none" text-anchor="middle" font-family="Georgia,serif">Moommie</text>`;
  }
  return `<svg viewBox="0 0 100 96" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#e6bf76" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
    <path d="M20 34 L28 14 L38 30 Z" fill="#2a2048"/>
    <path d="M80 34 L72 14 L62 30 Z" fill="#2a2048"/>
    <ellipse cx="50" cy="52" rx="34" ry="28" fill="#2a2048"/>
    <circle cx="38" cy="50" r="3.2" fill="#e6bf76" stroke="none"/>
    <circle cx="62" cy="50" r="3.2" fill="#e6bf76" stroke="none"/>
    <path d="M46 58 Q50 62 54 58" />
    <path d="M50 58 L50 54" />
    <path d="M14 60 Q6 58 4 52" />
    <path d="M14 66 Q6 68 4 72" />
    <path d="M86 60 Q94 58 96 52" />
    <path d="M86 66 Q94 68 96 72" />
    ${extra}
  </svg>`;
}

/* ---------- CONTENT DATA (edit freely) ---------- */

const REASONS = [
  "Because you can win an argument just by tilting your head and staring at me.",
  "Because you're cute even in the middle of a lecture about my life choices.",
  "Because I've lost so many arguments to you, I should legally be your intern by now.",
  "Because \u201cPoopie\u201d somehow became a term of endearment, and I'm fine with that.",
  "Because four and a half years later, my brain still short-circuits when you smile.",
  "Because you remember every date and plan down to the minute, and I still don't know how many days July has.",
  "Because your laugh is louder than it needs to be, and I wouldn't change a single decibel.",
  "Because you make \u201cwife material\u201d jokes and I never once disagree.",
  "Because you judge my fashion choices and you're always, annoyingly, correct.",
  "Because being called Moommie by you feels better than it has any right to.",
  "Because you take eleven selfies in a row and somehow all eleven are the best photo I've ever seen.",
  "Because you've seen me at my most ridiculous and decided to stay anyway.",
  "Because \u201cgrowth is not linear\u201d is now my legal defense for everything, and you invented it.",
  "Because my lawyer (me) has advised me to stop answering this question honestly. I'm ignoring him.",
  "Because five years from now, I still want to be losing arguments to you.",
  "Because \u201cBarbie Doll\u201d was clearly an understatement.",
  "Because you make ordinary Tuesdays feel like something worth remembering.",
  "Because out of literally everyone, you decided I was worth keeping around.",
  "Because you're my favorite person to annoy and be annoyed by, in exactly equal measure.",
  "Because it's you. It's just always, always going to be you."
];

const TIMELINE = [
  { year: "2022", line: "The beginning of us." },
  { year: "2023", line: "Still choosing each other." },
  { year: "2024", line: "More memories. More nonsense." },
  { year: "2025", line: "At this point, you're basically stuck with me." },
  { year: "2026", line: "4\u00BD years down\u2026 only about 2 more months until I get to say FIVE YEARS." }
];

// type: 'left' | 'right' | 'wide'   tag: 'evidence' | 'us' | null
const PHOTOS = [
  { src: "images/p01.jpg", cap: "Exhibit A: deploying the pout like it's a weapon. It is.", type: "left", tag: "evidence", tagText: "EVIDENCE #01" },
  { src: "images/p02.jpg", cap: "Somewhere in a forest, still finding time to give me this exact look.", type: "right", tag: null },
  { src: "images/p03.jpg", cap: "Unfairly photogenic in a bucket hat. Should be illegal.", type: "left", tag: null },
  { src: "images/p04.jpg", cap: "This smile right here \u2014 yeah, this is the one that started all of it.", type: "wide", tag: null },
  { src: "images/p05.jpg", cap: "The smile that continues to cause problems for my concentration.", type: "right", tag: "evidence", tagText: "EVIDENCE #02" },
  { src: "images/p06.jpg", cap: "Still smiling like she doesn't know exactly what she's doing to me.", type: "left", tag: null },
  { src: "images/p07.jpg", cap: "You, being ridiculously cute in your own mirror. As usual.", type: "right", tag: null },
  { src: "images/p08.jpg", cap: "Somewhere up high, looking out at a whole city \u2014 completely unaware she's the best view in the room.", type: "wide", tag: null },
  { src: "images/p09.jpg", cap: "Same evening, different angle. You, taking in the world.", type: "left", tag: null },
  { src: "images/p10.jpg", cap: "If I could only keep one photo of you, it might be this one. Just saying.", type: "right", tag: "evidence", tagText: "EVIDENCE #03" },
  { src: "images/p11.jpg", cap: "Mid-conversation, mid-thought \u2014 still somehow the prettiest person in a very red room.", type: "left", tag: null },
  { src: "images/p12.jpg", cap: "Caught mid-sip and still completely camera ready. Unfair, honestly.", type: "right", tag: null },
  { src: "images/p13.jpg", cap: "Us, at lunch right after bombing an interview \u2014 and somehow still managing to be ridiculous together.", type: "wide", tag: "us", tagText: "US" },
  { src: "images/p14.jpg", cap: "Not our best photo. Definitely one of my favorites. This is what \u201cus\u201d actually looks like.", type: "wide", tag: "us", tagText: "US" }
];

const LETTER_PARAGRAPHS = [
  "Moommie,",
  "If you're reading this, it means you made it through all of my questionable jokes, my even more questionable kitten drawings, and at least one very serious court case about July having 31 days. I'm proud of you.",
  "I don't really know how to write this part without sounding like a movie, so I'm just going to write it like me.",
  "It's been almost five years, Prerna. Five years of you being right about almost everything, me pretending I knew that already, and both of us somehow still choosing to show up for each other. We've fought about dumb things and important things. We've laughed until it wasn't even funny anymore, just loud. We've had days where we were annoying and days where we were unbearable and days where I looked at you and thought, quietly, \u201cyeah, I'm not going anywhere.\u201d",
  "You've become part of my everyday life in a way that kind of snuck up on me. Not the big, cinematic, movie-trailer kind of love. It's the kind that lives in small things. The way you send fifteen selfies and I genuinely can't pick a favorite because you look like that in all of them. The way you know what I'm about to say before I say it. The way you still, after all this time, manage to make me feel like the luckiest idiot alive.",
  "I still look at you the way I did back in 2022. Maybe more, honestly, because now I actually know you. The real you, not just the highlight reel.",
  "This is our fifth birthday together, Preraruuuuu. In about two months we hit five years, and I fully intend to make a very big deal out of it, so consider this your warning.",
  "Thank you for being my Moommie. My Poopie Queen. My Cutie Pie. My Barbie Doll. My person.",
  "Here's to every ridiculous, wonderful year after this one.",
  "I love you. Always have, since the very beginning of us."
];

/* ============================================================
   BUILD DOM CONTENT
   ============================================================ */

function el(tag, cls, html){
  const e = document.createElement(tag);
  if(cls) e.className = cls;
  if(html !== undefined) e.innerHTML = html;
  return e;
}

// reasons
let reasonIdx = -1;
let reasonOrder = [];
function shuffledOrder(n){
  const arr = Array.from({length:n}, (_,i)=>i);
  for(let i=arr.length-1;i>0;i--){
    const j = Math.floor(Math.random()*(i+1));
    [arr[i],arr[j]] = [arr[j],arr[i]];
  }
  return arr;
}
function showNextReason(){
  const card = document.getElementById('reasonCard');
  const countEl = document.getElementById('reasonCount');
  if(reasonOrder.length === 0) reasonOrder = shuffledOrder(REASONS.length);
  reasonIdx = (reasonIdx + 1);
  if(reasonIdx >= reasonOrder.length){ reasonOrder = shuffledOrder(REASONS.length); reasonIdx = 0; }
  const text = REASONS[reasonOrder[reasonIdx]];
  card.style.opacity = 0;
  setTimeout(()=>{
    card.querySelector('.reason-text').textContent = text;
    card.style.opacity = 1;
  }, 180);
  countEl.textContent = `reason ${(reasonIdx % REASONS.length) + 1} of ${REASONS.length}`;
}

// timeline
function buildTimeline(){
  const track = document.getElementById('timelineTrack');
  TIMELINE.forEach(item=>{
    const div = el('div','tl-item');
    div.innerHTML = `<div class="tl-year">${item.year}</div><div class="tl-line">${item.line}</div>`;
    track.appendChild(div);
  });
}

// photo gallery
function buildGallery(){
  const stream = document.getElementById('photoStream');
  PHOTOS.forEach((p, i)=>{
    const card = el('div', `photo-card ${p.type}`);
    let tagHtml = '';
    if(p.tag === 'evidence') tagHtml = `<div class="evidence-tag">${p.tagText}</div>`;
    if(p.tag === 'us') tagHtml = `<div class="us-tag">${p.tagText}</div>`;
    card.innerHTML = `${tagHtml}<img src="${p.src}" alt="Photo of Prerna" loading="lazy"><div class="cap">${p.cap}</div>`;
    stream.appendChild(card);
  });
}

// letter
function buildLetter(){
  const paper = document.getElementById('letterText');
  paper.innerHTML = LETTER_PARAGRAPHS.map(p=>`<p>${p}</p>`).join('');
}

/* ============================================================
   OPENING SEQUENCE
   ============================================================ */
function runOpeningSequence(){
  const l1 = document.getElementById('line1');
  const l2 = document.getElementById('line2');
  const btn = document.getElementById('openBtn');
  const hint = document.getElementById('openHint');
  setTimeout(()=> l1.classList.add('show'), 500);
  setTimeout(()=> l2.classList.add('show'), 2400);
  setTimeout(()=> btn.classList.add('show'), 4200);
  setTimeout(()=> hint.classList.add('show'), 4600);
}

function openSurprise(){
  const audio = document.getElementById('bgMusic');
  audio.play().catch(()=>{ /* file not added yet, or blocked — silently ignore */ });
  document.getElementById('musicToggle').classList.add('show');

  const opening = document.getElementById('opening');
  const exp = document.getElementById('experience');
  opening.style.transition = 'opacity 0.8s ease';
  opening.style.opacity = 0;
  setTimeout(()=>{
    opening.style.display = 'none';
    exp.classList.add('reveal');
    launchConfetti(document.getElementById('confettiHost'), 26);
  }, 750);
}

/* ============================================================
   PARTICLES / CONFETTI / STARS
   ============================================================ */
function scatterStars(container, count){
  for(let i=0;i<count;i++){
    const s = el('div','star');
    s.style.left = Math.random()*100 + '%';
    s.style.top = Math.random()*100 + '%';
    s.style.animationDelay = (Math.random()*4) + 's';
    container.appendChild(s);
  }
}

function launchConfetti(host, count){
  const colors = ['#e6bf76','#e29a9a','#faf2e6','#c97a86'];
  for(let i=0;i<count;i++){
    const p = el('div','confetti-piece');
    p.style.left = Math.random()*100 + '%';
    p.style.background = colors[Math.floor(Math.random()*colors.length)];
    p.style.animationDuration = (2.4 + Math.random()*1.6) + 's';
    p.style.animationDelay = (Math.random()*0.6) + 's';
    p.style.borderRadius = Math.random() > 0.5 ? '50%' : '2px';
    host.appendChild(p);
    setTimeout(()=> p.remove(), 4500);
  }
}

function floatHearts(host, count){
  for(let i=0;i<count;i++){
    const f = el('div','float-particle', '\u2764');
    f.style.left = Math.random()*100 + '%';
    f.style.bottom = '-5%';
    f.style.fontSize = (10 + Math.random()*10) + 'px';
    f.style.color = Math.random() > 0.5 ? '#e29a9a' : '#e6bf76';
    f.style.animationDuration = (7 + Math.random()*6) + 's';
    f.style.animationDelay = (Math.random()*5) + 's';
    host.appendChild(f);
  }
}

/* ============================================================
   MUSIC CONTROL
   ============================================================ */
function toggleMusic(){
  const audio = document.getElementById('bgMusic');
  const btn = document.getElementById('musicToggle');
  if(audio.paused){
    audio.play().catch(()=>{});
    btn.classList.remove('paused');
  } else {
    audio.pause();
    btn.classList.add('paused');
  }
}

/* ============================================================
   LOVE LETTER ENVELOPE
   ============================================================ */
function openEnvelope(){
  const env = document.getElementById('envelope');
  env.classList.add('open');
  setTimeout(()=>{
    document.getElementById('letterModal').classList.add('show');
  }, 500);
}
function closeLetter(){
  document.getElementById('letterModal').classList.remove('show');
}

/* ============================================================
   BADGE TOOLTIPS (tap on mobile)
   ============================================================ */
function wireBadges(){
  document.querySelectorAll('.badge').forEach(b=>{
    b.addEventListener('click', (e)=>{
      e.stopPropagation();
      document.querySelectorAll('.badge').forEach(o=>{ if(o!==b) o.classList.remove('tapped'); });
      b.classList.toggle('tapped');
    });
  });
  document.addEventListener('click', ()=>{
    document.querySelectorAll('.badge').forEach(o=> o.classList.remove('tapped'));
  });
}

/* ============================================================
   SCROLL REVEAL FOR TIMELINE
   ============================================================ */
function wireScrollReveal(){
  const items = document.querySelectorAll('.tl-item');
  const obs = new IntersectionObserver((entries)=>{
    entries.forEach(en=>{
      if(en.isIntersecting){ en.target.classList.add('inview'); }
    });
  }, { threshold: 0.3 });
  items.forEach(i=> obs.observe(i));
}

/* ============================================================
   INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', ()=>{
  // inject kittens
  document.getElementById('openingKitten').innerHTML = kittenWithProp('heart');
  document.getElementById('kittenHeart').innerHTML = kittenWithProp('heart');
  document.getElementById('kittenFlower').innerHTML = kittenWithProp('flower');
  document.getElementById('kittenZzz').innerHTML = kittenWithProp('zzz');
  document.getElementById('kittenSign').innerHTML = kittenWithProp('sign');
  document.getElementById('finaleKitten').innerHTML = kittenWithProp('heart');

  scatterStars(document.getElementById('starsOpening'), 60);
  scatterStars(document.getElementById('starsFinale'), 50);
  floatHearts(document.getElementById('heartsLetter'), 10);
  floatHearts(document.getElementById('heartsFinale'), 14);

  buildTimeline();
  buildGallery();
  buildLetter();

  const card = document.getElementById('reasonCard');
  card.style.transition = 'opacity 0.2s ease';
  showNextReason();

  document.getElementById('reasonBtn').addEventListener('click', showNextReason);
  document.getElementById('openBtn').addEventListener('click', openSurprise);
  document.getElementById('musicToggle').addEventListener('click', toggleMusic);
  document.getElementById('envelope').addEventListener('click', openEnvelope);
  document.getElementById('letterCloseBtn').addEventListener('click', closeLetter);
  document.getElementById('replayBtn').addEventListener('click', ()=>{
    window.scrollTo({top:0, behavior:'smooth'});
  });

  wireBadges();
  wireScrollReveal();
  runOpeningSequence();
});
